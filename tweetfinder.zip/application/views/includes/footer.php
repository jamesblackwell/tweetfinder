    <p class="pull-left">A <a href="http://jetrank.com/?ref=tweetfinder">JetRank.com</a>  Product. © <?=date('Y')?></p>
    </div> <!-- /container -->
  </body>
</html>