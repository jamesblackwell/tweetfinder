<div class="masthead">
	<ul class="nav nav-pills pull-right">
		<li class="active">
			<a href="<?=base_url()?>">Home</a>
		</li>
		<li>
			<a href="<?=base_url('about')?>">About</a>
		</li>
	</ul>
	<h3 class="muted">TweetFinder <small>by <a href="http://jetrank.com">JetRank.com</a></small></h3>
</div>
<hr>
